from __future__ import unicode_literals

from django.apps import AppConfig


class Blackbeltexam3AppConfig(AppConfig):
    name = 'blackBeltExam3_app'
