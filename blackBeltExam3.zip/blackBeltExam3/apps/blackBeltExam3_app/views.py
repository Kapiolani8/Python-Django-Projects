from django.shortcuts import render, redirect
from .models import * 
from django.contrib import messages 

def index(request):
    # messages1 = Message.objects.all()
    # User.objects.all().delete() clears users if stuff isn't working
    return render(request, "blackBeltExam3_app/index.html")

def register(request): 

    response = User.objects.register(
        request.POST["name"],
        request.POST["alias"],
        request.POST["email"],
        request.POST["dob"],
        request.POST["password"], 
        request.POST["confirm"]
    )
 
    if response["valid"]: 
        request.session["user_id"] = response["user"].id 
        return redirect("/home")
    else: 
        for error_message in response["errors"]: 
            messages.add_message(request, messages.ERROR, error_message)
        return redirect("/")

def login(request): 
    response = User.objects.login(
        request.POST["email"],
        request.POST["password"]
    )
    if response["valid"]: 
        request.session["user_id"] = response["user"].id 
        return redirect("/home")
    else: 
        for error_message in response["errors"]: 
            messages.add_message(request, messages.ERROR, error_message)
        return redirect("/")

def home(request): 
    # users = User.objects.all().exclude(id = request.session["user_id"]) 
    if "user_id" not in request.session: 
        return redirect("/")
    
    trips = TravelInfo.objects.all()
    yourTrips = TravelPlan.objects.filter(user_id = request.session["user_id"])

    for x in yourTrips: 
        trips = trips.exclude(id = x.trip.id)


    return render(request, "blackBeltExam3_app/home.html", {"trips": trips, "yourTrips": yourTrips})

   
    return render(request, "blackBeltExam3_app/home.html")

def addToTrip(request, id): 

    TravelPlan.objects.create(user_id = request.session["user_id"] , trip_id = id) 

    return redirect('/home')

def addTravelPlan(request): 
    return render(request, "blackBeltExam3_app/addTravelPlan.html")

def addTravelPlan1(request, methods = 'POST'): 
    itinerary = TravelInfo.objects.travelValidation(request.POST["destination"], request.POST["description"], request.POST["startDate"], request.POST["endDate"], request.session["user_id"])
    print type(itinerary)

    if type(itinerary) is list: 
        for error_message in itinerary: 
            messages.add_message(request, messages.ERROR, error_message)

    else: 
        TravelPlan.objects.create(user_id = request.session["user_id"] , trip_id = itinerary.id) 

    return redirect("/home")

def joinTrip(request, id):
    TravelPlan.objects.create(user_id = request.session["user_id"] , trip_id = id) 

    return redirect ("/home")

def tripInfo(request, id):
    request.session["user_id"] 

    print "IM RIGHT HERE",type(request.session["user_id"])
    your_users = User.objects.filter(id=id) 
    joinedUsers = TravelPlan.objects.filter(trip_id = id)
    print your_users
    context = {
        "users" : User.objects.all(),
        "user" : User.objects.get(id=request.session["user_id"]),
        "your_users" :  your_users, 
        "madeTrip" : TravelInfo.objects.filter(madeTrip = id),
        "joinedUsers" : joinedUsers
    }
    

    return render(request, "blackBeltExam3_app/show.html", context)

def logout(request): 
    request.session.clear()
    return redirect("/")